/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import controller.penyewa;
import java.time.LocalDate;

public class transaksi {
    private int id;
    private Penyewa penyewa;
    private properti properti;
    private LocalDate tanggal;
    private int durasi; // durasi sewa dalam hari
    private int totalHarga;

    public transaksi(int id, Penyewa penyewa, properti properti, LocalDate tanggal, int durasi) {
        this.id = id;
        this.penyewa = penyewa;
        this.properti = properti;
        this.tanggal = tanggal;
        this.durasi = durasi;
        this.totalHarga = hitungTotalHarga();
    }

    public transaksi(int id, penyewa penyewa, properti properti, LocalDate tanggal, int durasi) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private int hitungTotalHarga() {
        return properti.getHarga() * durasi;
    }

    // Getter
    public int getId() {
        return id;
    }

    public Penyewa getPenyewa() {
        return penyewa;
    }

    public properti getProperti() {
        return properti;
    }

    public LocalDate getTanggal() {
        return tanggal;
    }

    public int getDurasi() {
        return durasi;
    }

    public int getTotalHarga() {
        return totalHarga;
    }
}

