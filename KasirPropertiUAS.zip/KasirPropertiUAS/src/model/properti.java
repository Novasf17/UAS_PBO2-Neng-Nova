/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

public class properti {
    private int id;
    private String jenis;
    private int harga;

    public properti(properti properti, int id) {
        this.id = id;
        this.jenis = jenis;
        this.harga = harga;
    }

    // Getter & Setter
    public int getId() {
        return id;
    }

    public String getJenis() {
        return jenis;
    }

    public int getHarga() {
        return harga;
    }
}
