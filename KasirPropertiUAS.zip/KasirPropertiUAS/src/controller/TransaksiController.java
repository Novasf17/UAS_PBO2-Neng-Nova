/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import model.Penyewa;
import model.properti;
import model.transaksi;

import java.time.LocalDate;

public class TransaksiController {

    @FXML
    private TextField tfIdTransaksi;

    @FXML
    private TextField tfNamaPenyewa;

    @FXML
    private TextField tfNoTelepon;

    @FXML
    private TextField tfNamaProperti;

    @FXML
    private TextField tfHargaProperti;

    @FXML
    private DatePicker dpTanggalSewa;

    @FXML
    private TextField tfDurasi;

    @FXML
    private Label lblTotalHarga;

    @FXML
    private Button btnSimpan;

    @FXML
    private void initialize() {
        btnSimpan.setOnAction(e -> simpanTransaksi());
    }

    private void simpanTransaksi() {
        try {
            int id = Integer.parseInt(tfIdTransaksi.getText());
            String namaPenyewa = tfNamaPenyewa.getText();
            String noTelp = tfNoTelepon.getText();
            String namaProperti = tfNamaProperti.getText();
            int harga = Integer.parseInt(tfHargaProperti.getText());
            LocalDate tanggal = dpTanggalSewa.getValue();
            int durasi = Integer.parseInt(tfDurasi.getText());

            penyewa penyewa = new penyewa(namapenyewa, noTelp);
            properti properti = new properti(properti, harga);
            transaksi transaksi = new transaksi(id, penyewa, properti, tanggal, durasi);

            lblTotalHarga.setText("Rp " + transaksi.getTotalHarga());

            // Optional: tampilkan konfirmasi
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Sukses");
            alert.setHeaderText("Transaksi Berhasil Disimpan");
            alert.setContentText("Total Harga: Rp " + transaksi.getTotalHarga());
            alert.showAndWait();

        } catch (Exception ex) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Kesalahan");
            alert.setHeaderText("Input tidak valid");
            alert.setContentText("Pastikan semua field terisi dengan benar.");
            alert.showAndWait();
        }
    }

}

